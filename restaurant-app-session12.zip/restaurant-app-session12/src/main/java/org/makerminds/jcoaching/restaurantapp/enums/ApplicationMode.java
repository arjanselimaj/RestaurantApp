package org.makerminds.jcoaching.restaurantapp.enums;

public enum ApplicationMode {
	ORDER, TABLERESERVATION
}
