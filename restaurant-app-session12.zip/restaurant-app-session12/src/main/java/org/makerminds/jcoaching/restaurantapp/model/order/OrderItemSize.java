package org.makerminds.jcoaching.restaurantapp.model.order;

public enum OrderItemSize {
	SMALL,
	MEDIUM,
	LARGE,
	XXL
}
