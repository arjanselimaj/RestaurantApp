package org.makerminds.jcoaching.restaurantapp.enums;

public enum Location {
	KOSOVO, GERMANY
}
